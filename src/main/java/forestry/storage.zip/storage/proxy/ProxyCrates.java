package forestry.storage.proxy;

public class ProxyCrates {

	public void registerCrateModel() {
	}

}
