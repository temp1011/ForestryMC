package forestry.database.tiles;

import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.Container;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.core.tiles.TileBase;
import forestry.database.gui.ContainerDatabase;
import forestry.database.gui.GuiDatabase;
import forestry.database.inventory.InventoryDatabase;

public class TileDatabase extends TileBase {

	public TileDatabase() {
		setInternalInventory(new InventoryDatabase(this));
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public ContainerScreen getGui(PlayerEntity player, int data) {
		return new GuiDatabase(this, player);
	}

	@Override
	public Container getContainer(PlayerEntity player, int data) {
		return new ContainerDatabase(this, player.inventory);
	}
}
