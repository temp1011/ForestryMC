package forestry.cultivation.blocks;

import java.util.Random;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.BlockStateContainer;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemGroup;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import net.minecraftforge.client.model.ModelLoader;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.core.blocks.BlockBase;
import forestry.core.render.ParticleRender;
import forestry.cultivation.tiles.TilePlanter;

public class BlockPlanter extends BlockBase<BlockTypePlanter> {
	public static final PropertyBool MANUAL = PropertyBool.create("manual");

	public BlockPlanter(BlockTypePlanter blockType) {
		super(blockType, Material.WOOD);
		this.setDefaultState(blockState.getBaseState().with(FACING, Direction.NORTH).with(MANUAL, false));
	}

	@Override
	protected BlockStateContainer createBlockState() {
		return new BlockStateContainer(this, FACING, MANUAL);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public void randomDisplayTick(BlockState stateIn, World worldIn, BlockPos pos, Random rand) {
		if (blockType == BlockTypePlanter.FARM_ENDER) {
			for (int i = 0; i < 3; ++i) {
				ParticleRender.addPortalFx(worldIn, pos, rand);
			}
		}
	}

	@Override
	public BlockState getStateFromMeta(int meta) {
		int facing = meta & 7;
		return getDefaultState().with(FACING, Direction.fromAngle(facing)).with(MANUAL, (meta & 8) == 8);
	}

	@Override
	public int getMetaFromState(BlockState state) {
		if (state.getValue(MANUAL)) {
			return 8 + state.getValue(FACING).ordinal();
		}
		return state.getValue(FACING).ordinal();
	}

	@Override
	public TileEntity createTileEntity(World world, BlockState state) {
		TileEntity tile = super.createNewTileEntity(world, 0);
		if (tile instanceof TilePlanter) {
			TilePlanter planter = (TilePlanter) tile;
			planter.setManual(state.getValue(MANUAL));
		}
		return tile;
	}

	@Override
	public int damageDropped(BlockState state) {
		return state.getValue(MANUAL) ? 1 : 0;
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void registerStateMapper() {
		ModelLoader.setCustomStateMapper(this, new PlanterStateMapper());
	}

	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public BlockState getStateForPlacement(World world, BlockPos pos, Direction facing, float hitX, float hitY, float hitZ, int meta, LivingEntity placer, Hand hand) {
		ItemStack stack = placer.getHeldItem(hand);
		return getDefaultState().with(MANUAL, isManual(stack));
	}

	@Override
	public void getSubBlocks(ItemGroup itemIn, NonNullList<ItemStack> items) {
		for (byte i = 0; i < 2; i++) {
			items.add(get(i == 1));
		}
	}

	public static boolean isManual(ItemStack stack) {
		return stack.getMetadata() == 1;
	}

	public ItemStack get(boolean isManual) {
		return new ItemStack(this, 1, isManual ? 1 : 0);
	}
}
