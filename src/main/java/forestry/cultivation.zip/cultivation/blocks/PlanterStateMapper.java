package forestry.cultivation.blocks;

import com.google.common.collect.Maps;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.model.ModelResourceLocation;
import net.minecraft.util.Direction;
import net.minecraft.util.ResourceLocation;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.core.blocks.BlockBase;
import forestry.core.render.ForestryStateMapper;

@OnlyIn(Dist.CLIENT)
public class PlanterStateMapper extends ForestryStateMapper {

	@Override
	public Map<BlockState, ModelResourceLocation> putStateModelLocations(Block block) {
		for (Direction facing : Direction.values()) {
			if (facing == Direction.DOWN || facing == Direction.UP) {
				continue;
			}
			for (boolean manual : new boolean[]{false, true}) {
				BlockState state = block.getDefaultState().with(BlockBase.FACING, facing).with(BlockPlanter.MANUAL, manual);
				LinkedHashMap<IProperty<?>, Comparable<?>> properties = Maps.newLinkedHashMap(state.getProperties());
				properties.remove(BlockPlanter.MANUAL);
				ResourceLocation blockLocation = Block.REGISTRY.getNameForObject(block);
				String s = String.format("%s:%s", blockLocation.getNamespace(), blockLocation.getPath());
				mapStateModelLocations.put(state, new ModelResourceLocation(s, getPropertyString(properties)));
			}
		}

		return this.mapStateModelLocations;
	}

}
