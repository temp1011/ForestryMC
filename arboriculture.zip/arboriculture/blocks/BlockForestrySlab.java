package forestry.arboriculture.blocks;

import java.util.Collection;
import java.util.Random;

import net.minecraft.block.SlabBlock;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.BlockStateContainer;
import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.model.ModelBakery;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Direction;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.api.arboriculture.IWoodType;
import forestry.api.arboriculture.TreeManager;
import forestry.api.arboriculture.WoodBlockKind;
import forestry.api.core.IItemModelRegister;
import forestry.api.core.IModelManager;
import forestry.core.models.IStateMapperRegister;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodHelper;
import forestry.arboriculture.proxy.ProxyArboricultureClient;

public abstract class BlockForestrySlab<T extends Enum<T> & IWoodType> extends SlabBlock implements IWoodTyped, IItemModelRegister, IStateMapperRegister {
	protected static final int VARIANTS_PER_BLOCK = 8;

	private final boolean fireproof;
	private final int blockNumber;

	protected BlockForestrySlab(boolean fireproof, int blockNumber) {
		super(Material.WOOD);
		this.fireproof = fireproof;
		this.blockNumber = blockNumber;

		BlockState BlockState = this.blockState.getBaseState();

		if (!isDouble()) {
			BlockState = BlockState.with(HALF, EnumBlockHalf.BOTTOM);
		}

		PropertyWoodType<T> variant = getVariant();
		setDefaultState(BlockState.with(variant, variant.getFirstType()));

		setCreativeTab(Tabs.tabArboriculture);
		setHardness(2.0F);
		setResistance(5.0F);
		setSoundType(SoundType.WOOD);
		setHarvestLevel("axe", 0);
		useNeighborBrightness = true;
	}

	@Override
	public boolean isFireproof() {
		return fireproof;
	}

	public abstract PropertyWoodType<T> getVariant();

	public int getBlockNumber() {
		return blockNumber;
	}

	@Override
	protected BlockStateContainer createBlockState() {
		return this.isDouble() ? new BlockStateContainer(this, getVariant()) : new BlockStateContainer(this, HALF, getVariant());
	}

	@Override
	public BlockState getStateFromMeta(int meta) {
		T woodType = getWoodType(meta);
		BlockState BlockState = this.getDefaultState().with(getVariant(), woodType);

		if (!this.isDouble()) {
			BlockState = BlockState.with(HALF, (meta & 8) == 0 ? SlabBlock.EnumBlockHalf.BOTTOM : SlabBlock.EnumBlockHalf.TOP);
		}

		return BlockState;
	}

	@Override
	public abstract T getWoodType(int meta);

	@Override
	public int getMetaFromState(BlockState state) {
		int meta = damageDropped(state);

		if (!this.isDouble() && state.getValue(HALF) == SlabBlock.EnumBlockHalf.TOP) {
			meta |= 8;
		}

		return meta;
	}

	@Override
	public int damageDropped(BlockState state) {
		T woodType = state.getValue(getVariant());
		return woodType.getMetadata() - blockNumber * VARIANTS_PER_BLOCK;
	}

	@Override
	public Item getItemDropped(BlockState state, Random rand, int fortune) {
		T woodType = state.getValue(getVariant());
		ItemStack slab = TreeManager.woodAccess.getStack(woodType, getBlockKind(), isFireproof());
		return slab.getItem();
	}

	@SuppressWarnings("deprecation") // this is the way the vanilla slabs work
	@Override
	public ItemStack getItem(World worldIn, BlockPos pos, BlockState state) {
		T woodType = state.getValue(getVariant());
		ItemStack slab = TreeManager.woodAccess.getStack(woodType, getBlockKind(), isFireproof());
		return new ItemStack(slab.getItem(), 1, getMetaFromState(state));
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public void registerModel(Item item, IModelManager manager) {
		ModelBakery.registerItemVariants(item, WoodHelper.getDefaultResourceLocations(this));
		ProxyArboricultureClient.registerWoodMeshDefinition(item, new WoodHelper.WoodMeshDefinition(this));
	}

	@Override
	public String getTranslationKey(int meta) {
		T woodType = getWoodType(meta);
		return WoodHelper.getDisplayName(this, woodType);
	}

	@Override
	public void getSubBlocks(ItemGroup tab, NonNullList<ItemStack> list) {
		if (!isDouble()) {
			for (T woodType : getVariant().getAllowedValues()) {
				list.add(TreeManager.woodAccess.getStack(woodType, getBlockKind(), fireproof));
			}
		}
	}

	@Override
	public float getBlockHardness(BlockState blockState, World worldIn, BlockPos pos) {
		int meta = getMetaFromState(blockState);
		T woodType = getWoodType(meta);
		return woodType.getHardness();
	}

	@Override
	public int getFlammability(IBlockReader world, BlockPos pos, Direction face) {
		return fireproof ? 0 : 20;
	}

	@Override
	public int getFireSpreadSpeed(IBlockReader world, BlockPos pos, Direction face) {
		return fireproof ? 0 : 5;
	}

	@Override
	public WoodBlockKind getBlockKind() {
		return WoodBlockKind.SLAB;
	}

	@Override
	public IProperty getVariantProperty() {
		return getVariant();
	}

	@Override
	public Comparable<?> getTypeForItem(ItemStack stack) {
		return getWoodType(stack.getMetadata());
	}

	@Override
	public Collection<T> getWoodTypes() {
		return getVariant().getAllowedValues();
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void registerStateMapper() {
		String blockPath = isDouble() ? "double_slab" : getBlockKind().toString();
		ProxyArboricultureClient.registerWoodStateMapper(this, new WoodTypeStateMapper(this, blockPath, getVariant()));
	}
}
