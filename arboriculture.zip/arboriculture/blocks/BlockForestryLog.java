package forestry.arboriculture.blocks;

import java.util.Collection;

import net.minecraft.block.LogBlock;
import net.minecraft.block.BlockStateContainer;
import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.model.ModelBakery;
import net.minecraft.item.ItemGroup;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Direction;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.api.arboriculture.IWoodType;
import forestry.api.arboriculture.TreeManager;
import forestry.api.arboriculture.WoodBlockKind;
import forestry.api.core.IItemModelRegister;
import forestry.api.core.IModelManager;
import forestry.core.models.IStateMapperRegister;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodHelper;
import forestry.arboriculture.proxy.ProxyArboricultureClient;

public abstract class BlockForestryLog<T extends Enum<T> & IWoodType> extends LogBlock implements IWoodTyped, IStateMapperRegister, IItemModelRegister {
	protected static final int VARIANTS_PER_BLOCK = 4;

	private final boolean fireproof;
	private final int blockNumber;

	protected BlockForestryLog(boolean fireproof, int blockNumber) {
		this.fireproof = fireproof;
		this.blockNumber = blockNumber;

		PropertyWoodType<T> variant = getVariant();
		setDefaultState(this.blockState.getBaseState().with(variant, variant.getFirstType()).with(LOG_AXIS, EnumAxis.Y));

		setHarvestLevel("axe", 0);
		setCreativeTab(Tabs.tabArboriculture);
	}


	@Override
	public final WoodBlockKind getBlockKind() {
		return WoodBlockKind.LOG;
	}

	@Override
	public final boolean isFireproof() {
		return fireproof;
	}

	public final int getBlockNumber() {
		return blockNumber;
	}

	private static EnumAxis getAxis(int meta) {
		switch (meta & 12) {
			case 0:
				return EnumAxis.Y;
			case 4:
				return EnumAxis.X;
			case 8:
				return EnumAxis.Z;
			default:
				return EnumAxis.NONE;
		}
	}

	@Override
	public final BlockState getStateFromMeta(int meta) {
		T woodType = getWoodType(meta);
		EnumAxis axis = getAxis(meta);
		return getDefaultState().with(getVariant(), woodType).with(LOG_AXIS, axis);
	}

	@SuppressWarnings("incomplete-switch")
	@Override
	public final int getMetaFromState(BlockState state) {
		int i = damageDropped(state);

		switch (state.getValue(LOG_AXIS)) {
			case X:
				i |= 4;
				break;
			case Z:
				i |= 8;
				break;
			case NONE:
				i |= 12;
		}

		return i;
	}

	public abstract PropertyWoodType<T> getVariant();

	@Override
	public abstract T getWoodType(int meta);

	@Override
	public final Collection<T> getWoodTypes() {
		return getVariant().getAllowedValues();
	}

	@Override
	protected final BlockStateContainer createBlockState() {
		return new BlockStateContainer(this, getVariant(), LOG_AXIS);
	}

	@Override
	public final int damageDropped(BlockState state) {
		return state.getValue(getVariant()).getMetadata() - blockNumber * VARIANTS_PER_BLOCK;
	}

	@Override
	public BlockState getStateForPlacement(World worldIn, BlockPos pos, Direction facing, float hitX, float hitY, float hitZ, int meta, LivingEntity placer) {
		EnumAxis axis = EnumAxis.fromFacingAxis(facing.getAxis());
		T woodType = getWoodType(meta);
		return getDefaultState().with(getVariant(), woodType).with(LOG_AXIS, axis);
	}

	@Override
	public void getSubBlocks(ItemGroup tab, NonNullList<ItemStack> list) {
		for (T woodType : getVariant().getAllowedValues()) {
			list.add(TreeManager.woodAccess.getStack(woodType, getBlockKind(), fireproof));
		}
	}

	@Override
	public final float getBlockHardness(BlockState blockState, World worldIn, BlockPos pos) {
		int meta = getMetaFromState(blockState);
		T woodType = getWoodType(meta);
		return woodType.getHardness();
	}

	@Override
	protected ItemStack getSilkTouchDrop(BlockState state) {
		ItemStack silkTouchDrop = super.getSilkTouchDrop(state);
		int damage = this.damageDropped(state);
		silkTouchDrop.setItemDamage(damage);
		return silkTouchDrop;
	}

	/* PROPERTIES */
	@Override
	public final int getFireSpreadSpeed(IBlockReader world, BlockPos pos, Direction face) {
		if (fireproof) {
			return 0;
		} else if (face == Direction.DOWN) {
			return 20;
		} else if (face != Direction.UP) {
			return 10;
		} else {
			return 5;
		}
	}

	@Override
	public final int getFlammability(IBlockReader world, BlockPos pos, Direction face) {
		if (fireproof) {
			return 0;
		}
		return 5;
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public final void registerModel(Item item, IModelManager manager) {
		ModelBakery.registerItemVariants(item, WoodHelper.getDefaultResourceLocations(this));
		ProxyArboricultureClient.registerWoodMeshDefinition(item, new WoodHelper.WoodMeshDefinition(this));
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public final void registerStateMapper() {
		ProxyArboricultureClient.registerWoodStateMapper(this, new WoodTypeStateMapper(this, getVariant()));
	}
}
