package forestry.book.items;

import javax.annotation.Nullable;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.world.World;


import net.minecraftforge.api.distmarker.Dist;

import net.minecraftforge.api.distmarker.OnlyIn;
import forestry.api.book.IForesterBook;
import forestry.book.BookLoader;
import forestry.book.gui.GuiForesterBook;
import forestry.book.gui.GuiForestryBookCategories;
import forestry.core.items.ItemWithGui;

public class ItemForesterBook extends ItemWithGui {
	public ItemForesterBook() {

	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, PlayerEntity playerIn, Hand handIn) {
		openGui(playerIn);

		ItemStack stack = playerIn.getHeldItem(handIn);
		return ActionResult.newResult(ActionResultType.SUCCESS, stack);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public Screen getGui(PlayerEntity player, ItemStack heldItem, int data) {
		IForesterBook book = BookLoader.INSTANCE.loadBook();
		GuiForesterBook guiScreen = GuiForesterBook.getGuiScreen();
		if (guiScreen != null && guiScreen.getBook() != book) {
			GuiForesterBook.setGuiScreen(null);
			guiScreen = null;
		}
		return guiScreen != null ? guiScreen : new GuiForestryBookCategories(book);
	}

	@Nullable
	@Override
	public Container getContainer(PlayerEntity player, ItemStack heldItem, int data) {
		return null;
	}
}
