package forestry.book;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

import forestry.core.config.Config;

public class EventHandlerBook {

	private static final String HAS_BOOK = "forestry.spawned_book";

	@SubscribeEvent
	public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (Config.spawnWithBook) {
			CompoundNBT playerData = event.player.getEntityData();
			CompoundNBT data = playerData.hasKey(PlayerEntity.PERSISTED_NBT_TAG) ? playerData.getCompoundNBT(PlayerEntity.PERSISTED_NBT_TAG) : new CompoundNBT();

			if (!data.getBoolean(HAS_BOOK)) {
				ItemHandlerHelper.giveItemToPlayer(event.player, new ItemStack(ModuleBook.getItems().book));
				data.setBoolean(HAS_BOOK, true);
				playerData.setTag(PlayerEntity.PERSISTED_NBT_TAG, data);
			}
		}
	}
}
